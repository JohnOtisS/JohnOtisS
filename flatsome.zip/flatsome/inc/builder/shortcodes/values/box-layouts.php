<?php
return array(
	'none'     => 'None',
	'default'  => 'Default',
	'normal'   => 'Normal',
	'overlay'  => 'Overlay',
	'shade'    => 'Shade',
	'vertical' => 'Vertical',
	'label'    => 'Label',
	'push'     => 'Push',
	'badge'    => 'Badge',
	'bounce'   => 'Bounce',
);
