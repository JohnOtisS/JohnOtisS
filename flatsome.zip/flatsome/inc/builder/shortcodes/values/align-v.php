<?php

return array(
	'top'    => 'Top',
    'middle' => 'Middle',
    'bottom' => 'Bottom',
);
