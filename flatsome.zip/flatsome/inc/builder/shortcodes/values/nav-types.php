<?php

return array(
    'normal' => 'Normal',
    'uppercase' => 'Uppercase',
);
