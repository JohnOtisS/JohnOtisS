<?php return array(
    '' => 'None',
	'fade-in' => 'Fade In',
    'fade-out' => 'Fade Out',
    'slide' => 'Slide In',
    'zoom' => 'Zoom Out',
    'zoom-in' => 'Zoom In',
    'blur' => 'Blur In',
    'bounce' => 'Bounce',
    'invert' => 'Invert',
);
