<?php
/**
 * Builder menu label list
 *
 * @package flatsome
 */

return array(
	''                => 'None',
	'label-sale'      => 'Sale',
	'label-popular'   => 'Popular',
  'label-hot'       => 'Hot',
  'label-new'       => 'New',
);
