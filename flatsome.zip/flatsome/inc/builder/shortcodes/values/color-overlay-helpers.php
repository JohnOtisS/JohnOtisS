<?php

return array(
    array('title' => 'Dark','value' => 'rgba(0,0,0,.5)'),
    array('title' => 'White','value' => 'rgba(255,255,255,.5)'),
    array('title' => 'Primary','value' => 'rgba(98,127,154,.5)'),
);
